#include <stdio.h>
int main() {
printf("%d\n",(23 + 4)); }
