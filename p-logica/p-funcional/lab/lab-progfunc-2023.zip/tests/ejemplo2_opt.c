#include <stdio.h>
int _double(int _x){
return ((2 * _x)); };
int main() {
printf("%d\n",(23 + _double(2))); }
