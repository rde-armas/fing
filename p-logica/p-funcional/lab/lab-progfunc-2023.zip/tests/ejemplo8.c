#include <stdio.h>
int main() {
int _let0(int _x){
return (_x); };
int _let2(int _x){
int _let1(int _y){
return (((_x + _y) + 5)); };
return (_let1((4 + _x))); };
printf("%d\n",_let2(_let0(3))); }
