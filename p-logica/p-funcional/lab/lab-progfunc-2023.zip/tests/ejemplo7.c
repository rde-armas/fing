#include <stdio.h>
int _foo(int _x,int _y){
int _let0(int _x){
return (_x); };
int _let1(int _y){
return ((_y + 1)); };
return ((_let0(4) + _let1((11 + 2)))); };
int _bar(int _x){
int _let1(int _x){
int _let0(int _x){
return (_x); };
return (_let0(2)); };
return (_let1(1)); };
int main() {
int _let0(int _x){
return ((_foo(_x,4) + _bar(_x))); };
printf("%d\n",_let0(2)); }
