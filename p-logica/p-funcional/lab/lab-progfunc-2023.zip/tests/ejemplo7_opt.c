#include <stdio.h>
int _foo(int _x,int _y){
int _let0(int _y){
return ((_y + 1)); };
return ((4 + _let0((11 + 2)))); };
int _bar(int _x){
return (2); };
int main() {
printf("%d\n",(_foo(2,4) + _bar(2))); }
