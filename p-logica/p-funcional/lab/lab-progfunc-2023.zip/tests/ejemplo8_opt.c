#include <stdio.h>
int main() {
int _let0(int _y){
return (((3 + _y) + 5)); };
printf("%d\n",_let0((4 + 3))); }
